﻿namespace GuessNumberGameNet6.Interfaces;

public interface IConsoleIo
{
    void WriteLine(object message);
    string ReadLine();
}