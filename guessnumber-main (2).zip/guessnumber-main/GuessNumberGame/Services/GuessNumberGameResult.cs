﻿namespace GuessNumberGameNet6.Services;

public enum GuessNumberGameResult
{
    Equal,
    Less,
    Height
}